matlab-tree
===========

A MATLAB class to represent the tree data structure.
